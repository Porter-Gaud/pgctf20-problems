[< Go to Cryptography](/Cryptography) OR [<< Go to Home](/)
# Math Problem - 50 Points
## Problem
Your math teacher gave you this problem on the quiz. Good luck figuring it out because it definitely wasn't covered in the notes 

## Solution
Just run that block of text through a Base 64 decoder to get a block of coordinate points. You can either manually graph them or format them and paste them into Desmos (or any other equivalent tool). Once graphed the points create a QR code that reveals the flag.

## Flag
`pgctf{bethereorbesquared}`
